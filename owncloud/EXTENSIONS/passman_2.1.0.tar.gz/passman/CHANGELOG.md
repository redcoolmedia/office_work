## [Unreleased]
### Updated
- Updated to passman 2.0.0

## 2.0.0 – 2016-12-31
### Added
- Password sharing
- Vaults
- Change vault passwords
- Unit tests

### Changed
- Passman API overhaul
- Rewrite of code base
- New passman repo at https://github.com/nextcloud/passman
### Fixed
- A lot of small bug fixes

### Removed
- Old passman API
