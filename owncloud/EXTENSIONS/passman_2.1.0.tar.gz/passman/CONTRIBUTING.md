If you want to contribute make sure the commits are `verified`.   
You can read how to GPG sign you commits [here](https://help.github.com/articles/signing-commits-using-gpg/).