BDESK PHOTO
============

Bdesk Photo is a tinymce plugin for BuddyexpressDesk to allow administrator to embed image in post as a base64 encode image.

There are some restrictions in plugin like:
 1. The image must be equal to or less then 500KB
 2. The image must be equal to or less then 800x800 in dimensions.

Note: If you want to remove restriction replace plugin.min.js with the code found here https://gist.github.com/arsalanshah/10623688

Last Edit README.md : Leonard Walter

COPYRIGHT 2014 Informatikon Technologies informatikon.com
