<?php
namespace OCA\Passman;
$tmpl = new \OCP\Template('passman', 'part.admin');
return $tmpl->fetchPage();